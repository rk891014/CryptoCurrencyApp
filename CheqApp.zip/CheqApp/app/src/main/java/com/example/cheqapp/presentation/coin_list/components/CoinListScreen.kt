package com.example.cheqapp.presentation.coin_list.components

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.cheqapp.presentation.coin_list.CoinListViewModel

@Composable
fun CoinListScreen(
    navController : NavController,
    viewModel: CoinListViewModel
) {

}