package com.example.cheqapp.data.remote.dto

data class LinksExtended(
    val stats: Stats,
    val type: String,
    val url: String
)