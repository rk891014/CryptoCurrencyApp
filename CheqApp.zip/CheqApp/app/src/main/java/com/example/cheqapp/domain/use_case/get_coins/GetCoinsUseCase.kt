package com.example.cheqapp.domain.use_case.get_coins

import com.example.cheqapp.common.Resourses
import com.example.cheqapp.data.remote.dto.toCoin
import com.example.cheqapp.domain.model.Coin
import com.example.cheqapp.domain.repository.CoinRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject

class GetCoinsUseCase @Inject constructor(
    private val repository: CoinRepository
) {
//    we are returning here list of Coins as ui and viemodel we will using domain model coin not data model coindto.
    operator fun invoke(): Flow<Resourses<List<Coin>>> = flow {
        try {
            emit(Resourses.Loading())
//            as we passed the list of coin dto and it aspect a list of coins to we need to map each coin in the list
            val coins = repository.getCoins().map {
                it.toCoin()
            }
            emit(Resourses.Success(coins))
        } catch (e: HttpException) {
            emit(Resourses.Error(e.localizedMessage ?: "An unexpected error occured"))
        } catch (e: IOException) {
            emit(Resourses.Error("Couldn't reach server. Check Your Internet Connection."))
        }
    }
}