package com.example.cheqapp.data.remote.dto

data class Tag(
    val coin_counter: Int,
    val ico_counter: Int,
    val id: String,
    val name: String
)