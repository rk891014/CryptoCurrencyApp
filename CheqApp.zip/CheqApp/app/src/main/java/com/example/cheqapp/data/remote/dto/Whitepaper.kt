package com.example.cheqapp.data.remote.dto

data class Whitepaper(
    val link: String,
    val thumbnail: String
)